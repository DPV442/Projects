"""
Importing all the neccessary modules and packages
"""

from Backend.RSE import RealTimeChatBotAI
from Backend.STT import SpeechRecognition
from Backend.Model import DecisionMakingModel
from Backend.Chatbot import ChatBotAI
from Backend.Automation import *
from dotenv import dotenv_values
from Backend.TTS import TTS
from Frontend.GUI import *
import mtranslate as mt
from time import sleep
import threading
import json

""" Default Message if no chats are found """
DefaultMessage = f'''{Username} : Hello {Assistantname}, How are you?
{Assistantname} : Welcome {Username}. I am doing well. How may i help you?'''

def ReadENV():

    """ This function reads the environment variables from .env file. """

    env_vars = dotenv_values('.env')
    Username = env_vars.get('Username')
    Assistantname = env_vars.get('Assistantname')
    OpenAIKey = env_vars.get('OpenAIKey')
    GroqAPI = env_vars.get('GroqAPI')
    AssistantVoice = env_vars.get('AssistantVoice')
    InputLanguage = env_vars.get('InputLanguage')
    return Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage

""" Extracting the environment variables """
Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage = ReadENV()

def UniversalTranslator(Text):
    
    """ This function translates the text [ Any Language ] into english. """

    SetAssistantStatus("Translating...")
    english_translation = mt.translate(Text, "en", "auto")
    return english_translation.capitalize()

def ShowDefaultChatIfNoChats():

    """ This function shows the default chat on GUI if no chats are found. """

    File = open('ChatLog.json',"r", encoding='utf-8')
    if len(File.read())<5:
        with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
            file.write("")

        with open(TempDirectoryPath('Responses.data'), 'w', encoding='utf-8') as file:
            file.write(DefaultMessage)

def ReadChatLogJson():

    """ This function reads the chat log json file and returns it """

    with open('ChatLog.json', 'r', encoding='utf-8') as file:
        chatlog_data = json.load(file)
    return chatlog_data

def ChatLogIntegration():

    """ This function extracts the chats from ChatLog.json file and saves it in Database.data. """

    json_data = ReadChatLogJson()
    formatted_chatlog = ""
    for entry in json_data:
        if entry["role"] == "user":
                formatted_chatlog += f"User: {entry['content']}\n"
        elif entry["role"] == "assistant":
                formatted_chatlog += f"Assistant: {entry['content']}\n"
    formatted_chatlog = formatted_chatlog.replace("User",Username + " ")
    formatted_chatlog = formatted_chatlog.replace("Assistant",Assistantname + " ")

    with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
        file.write(AnswerModifier(formatted_chatlog))

def ShowChatsOnGUI():

    """ This function shows the chats on GUI Chat screen. """

    File = open(TempDirectoryPath('Database.data'),"r", encoding='utf-8')
    Data = File.read()
    if len(str(Data))>0:
        lines = Data.split('\n')
        result = '\n'.join(lines)
        File.close()
        File = open(TempDirectoryPath('Responses.data'),"w", encoding='utf-8')
        File.write(result)
        File.close()

def InitialExecution():

    """ This function executes at the start of the program to setup all the necessary things. """

    SetMicrophoneStatus("False")
    ShowTextToScreen("")
    ShowDefaultChatIfNoChats()
    ChatLogIntegration()
    ShowChatsOnGUI()

""" Executing all the neccessary functions """
InitialExecution()

def MainExecution():

    """ This function is responsible for the main execution of the program, it executes when the microphone is on, it answers the query and speaks the answer. """

    SetAssistantStatus("Listening...")
    Query: str = SpeechRecognition() 
    Query: str = UniversalTranslator(Query) if "en" not in InputLanguage else Query.capitalize()
    Query: str = QueryModifier(Query)
    SetAssistantStatus("Thinking...")
    ShowTextToScreen(f"{Username} : {Query}")
    Decision: str = DecisionMakingModel(Query)

    if "False" == Decision:
        Answer = ChatBotAI(Query)
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "True" == Decision:
        SetAssistantStatus("Searching...")
        Answer = RealTimeChatBotAI(Query)
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "Content" == Decision.split(" ")[0]:
        SetAssistantStatus("Generating...")
        Answer = ContentWriterAI(Query)
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "play" == Decision.split(" ")[0]:
        SetAssistantStatus("Playing...")
        Answer = Play(Decision.replace("play ",""))
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "open" == Decision.split(" ")[0]:
        SetAssistantStatus("Launching...")
        Answer = OpenApplications(Decision)
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "google search" in Decision:
        SetAssistantStatus("Searching...")
        Answer = Search(Query.replace("google search ",""))
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    elif "youtube search" in Decision:
        SetAssistantStatus("Searching...")
        Answer = YouTubeSearch(Query.replace("youtube search ",""))
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

    else:
        Answer = ChatBotAI(Query)
        ShowTextToScreen(f"{Assistantname} : {Answer}")
        SetAssistantStatus("Answering...")
        TTS(Answer)

def FirstThread():

    """ This function is used to integrate the GUI with the Backend. """

    while True:
        CurrentStatus = GetMicrophoneStatus()

        if CurrentStatus == "True":
            MainExecution()

        else:
            AIStatus = GetAssistantStatus()
            
            if "Available..." in AIStatus:
                sleep(0.1)

            else:
                SetAssistantStatus("Available...")

def SecondThread():

    """ This function is used to integrate the GUI. """

    GraphicalUserInterface()

if __name__ == "__main__":

    """ Running the frontend and backend simultaneously. """

    thread2 = threading.Thread(target=FirstThread, daemon=True)
    thread2.start()
    SecondThread()

