"""
Importing all the neccessary modules and packages
"""

from groq import Groq
from json import load,dump
import datetime
from dotenv import dotenv_values

def ReadENV():

    """This function reads the environment variables from .env file"""

    env_vars = dotenv_values('.env')
    Username = env_vars.get('Username')
    Assistantname = env_vars.get('AssistantName')
    OpenAIKey = env_vars.get('OpenAIKey')
    GroqAPI = env_vars.get('GroqAPI')
    AssistantVoice = env_vars.get('AssistantVoice')
    InputLanguage = env_vars.get('InputLanguage')
    return Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage

""" Extracting the environment variables """
Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage = ReadENV()
client = Groq(api_key=GroqAPI)
messages = []

SystemChatBot = [
    {"role": "system",
    "content": f"Hello I'm {Username}, You're an advanced AI assistant {Assistantname}, like Jarvis from the MCU. Speak like Jarvis, Be concise and answer as short as you can in the least tokens. Do not tell time until i ask. ***Do not give garbage response*** Example random informations"},
    {"role": "user",
    "content": "Hi"},
    {"role": "assistant",
    "content": "Hello, how can I help you?"}
    ]

try:

    with open("ChatLog.json","r") as f:
        messages = load(f)

except:

    with open("ChatLog.json","w") as f:
        dump([],f)

def Information():

    """ This function returns the realtime information and the AI uses that information if needed. """

    data=""
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")
    data+=f"Use This Realtime Information. if needed\n"
    data+=f"Day: {day}\n"
    data+=f"Date: {date}\n"
    data+=f"Month: {month}\n"
    data+=f"Year: {year}\n"
    data+=f"Time: {hour} hours :{minute} minutes :{second} seconds.\n"
    return data

def ChatBotAI(prompt):

    """This functions returns the answer from the chatbot and saves it in a json file"""

    try:

        with open("ChatLog.json","r") as f:
            messages:dict = load(f)

        messages.append({"role": "user", "content": f"{prompt}"})

        completion = client.chat.completions.create(
        model = "mixtral-8x7b-32768",
        messages = SystemChatBot + [{"role": "system", "content": Information()}] + messages,
        max_tokens=1024,
        temperature=0.7,
        top_p=1,
        stream=True,
        stop=None)

        Answer =""

        for chunk in completion:

            if chunk.choices[0].delta.content:
                Answer += chunk.choices[0].delta.content

        Answer = Answer.replace("</s>", "")
        Answer = Answer[0:Answer.find("[")]
        messages.append({"role": "assistant", "content": Answer})

        with open("ChatLog.json","w") as f:
            dump(messages,f,indent=4)

        return Answer
    
    except Exception as e:
        print(e)

        with open("ChatLog.json","w") as f:
            dump([],f,indent=4)

        return ChatBotAI(prompt)

if __name__ == "__main__":
    
    while True:
        
        print(ChatBotAI(input("Enter Your Question : ")))

