"""
Importing all the neccessary modules and packages
"""

from groq import Groq
from googlesearch import search
from json import load,dump
from dotenv import load_dotenv, dotenv_values

def ReadENV():

    """This function reads the environment variables from .env file"""

    env_vars = dotenv_values('.env')
    Username = env_vars.get('Username')
    Assistantname = env_vars.get('AssistantName')
    OpenAIKey = env_vars.get('OpenAIKey')
    GroqAPI = env_vars.get('GroqAPI')
    AssistantVoice = env_vars.get('AssistantVoice')
    InputLanguage = env_vars.get('InputLanguage')
    return Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage

""" Extracting the environment variables """
Username, Assistantname, OpenAIKey, GroqAPI , AssistantVoice ,InputLanguage = ReadENV()
load_dotenv()
client = Groq(api_key = GroqAPI)

try:
    with open("ChatLog.json","r") as f:
        messages = load(f)

except:
    with open("ChatLog.json","w") as f:
        dump([],f)

def GoogleSearch(query):

    """This functions returns the raw data by searching the topic on google."""

    results = list(search(query, advanced=True, num_results=5))
    Answer =f"The search results for f'{query} 'are : \n[start]\n"

    for i in results:
        Answer += f"Title : {i.title}\nDiscription : {i.description}\n\n"

    Answer += "[end]"
    return Answer

SystemChat = [
    {"role": "system",
    "content": f"Hello, I'm {Username}, You're an advanced AI assistant {Assistantname}, like Jarvis from the MCU. Speak like Jarvis, Be concise and answer as short as you can in the least tokens. *** Do not give garbage response *** Example random informations, And you all real time data."},
    {"role": "user",
    "content": "Do you have realtime data ?"},
    {"role": "assistant",
    "content": "Yes, I have all real time data."}]

def RealTimeChatBotAI(prompt):

    """This function finds the accurate answer from the raw data and returns it in a professing way."""

    global messages,SystemChat

    with open("ChatLog.json","r") as f:
        messages = load(f)
    
    SystemChat.append({"role": "system", "content": GoogleSearch(prompt)})
    messages.append({"role": "user", "content": prompt})

    completion = client.chat.completions.create(
    model = "mixtral-8x7b-32768",
    messages = SystemChat + messages,
    temperature = 0.7,
    max_tokens = 2048,
    top_p = 1,
    stream = True,
    stop = None)

    Answer = ""

    for chunk in completion:
        if chunk.choices[0].delta.content:
            Answer += chunk.choices[0].delta.content
    
    Answer = Answer.strip().replace("</s>","")
    Answer = Answer[0:Answer.find("[")]
    messages.append({"role": "assistant", "content": Answer})

    with open("ChatLog.json","w") as f:
        dump(messages,f,indent=4)

    SystemChat.pop()
    return Answer

if __name__ == "__main__":
    while True:
        prompt = input("Enter your query: ")
        print(RealTimeChatBotAI(prompt))

