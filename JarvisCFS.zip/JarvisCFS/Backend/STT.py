"""
Importing all the neccessary modules and packages
"""

from selenium import webdriver
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import os
import platform

current_dir = os.getcwd()
system_platform = platform.system()

""" This makes the code more compatible for different platforms. """
if system_platform == 'Windows':
    Link = rf"{current_dir}\Backend\Voice.html"
elif system_platform == 'Darwin':
    Link = rf"file:///{current_dir}/Backend/Voice.html"

""" Setting up the chrome driver for speech recognition. """
chrome_options = Options()
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.142.86 Safari/537.36"
chrome_options.add_argument(f'user-agent={user_agent}')
chrome_options.add_argument("--use-fake-ui-for-media-stream")
chrome_options.add_argument("--use-fake-device-for-media-stream")
chrome_options.add_argument("--headless=new")
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

def SpeechRecognition():

    """ This function performs speech recognition. """

    driver.get(Link)
    driver.find_element(by=By.ID,value="start").click()

    while True:

        try:
                Text = driver.find_element(by=By.ID,value="output").text

                if Text:
                    driver.find_element(by=By.ID,value="end").click()
                    return Text

                else:
                    sleep(0.333)

        except:
                pass

if __name__ == "__main__":

    while True:

        Text = SpeechRecognition()
        print(Text)

